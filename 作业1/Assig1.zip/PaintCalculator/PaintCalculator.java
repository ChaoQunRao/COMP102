// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a XMUT102 assignment.
// You may not distribute it in any other way without permission.

/* Code for XMUT102 - 2018T2
 * Name:
 * Username:
 * ID:
 */

import ecs100.*;

/** Program for calculating amount of paint required to paint a room */

public class PaintCalculator{

    public static final double DOOR_HEIGHT = 2.1;        // Height of the doors
    public static final double DOOR_WIDTH = 0.8;         // Width of the doors
    public static final double SQ_METERS_PER_LITRE = 15.0; // Area covered by 1 litre of paint

    /** Calculates and prints litres of paint needed to paint a room
     *  with four walls (excluding the doors, floor, and ceiling)
     */
    public void calculatePaintCore(){
        /*# YOUR CODE HERE */

    }

    /** Calculates and prints litres of paint needed to paint
     *  - the four walls of a room (excluding the doors and windows)
     *  - the ceiling (different type of paint)
     */
    public void calculatePaintCompletion(){
        /*# YOUR CODE HERE */

    }

}
