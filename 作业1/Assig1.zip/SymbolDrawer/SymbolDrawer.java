// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a XMUT102 assignment.
// You may not distribute it in any other way without permission.

/* Code for XMUT102 - 2018T2
 * Name:
 * Username:
 * ID:
 */

import ecs100.*;
import java.awt.Color;

/**
 * Draws various symbols: flags, signs, and car logos
 *
 * You can find lots of flag details (including the correct dimensions and colours)
 * from  http://www.crwflags.com/fotw/flags/    
 */
public class SymbolDrawer{

    /**   CORE
     * Draw the flag of France.
     * The flag has three vertical stripes;
     * The left is blue, the right is red and the middle is white.
     * The flag is 2/3 as high as it is wide (ratio 2:3).
     */
    public void drawFranceFlag(double left, double top, double width){
        /*# YOUR CODE HERE */

    }

    /**   CORE
     * Draw the hospital sign - a blue square with a big white centred H.
     * The H is made of 3 rectangular strips
     */
    public void drawHospitalSign(double left, double top, double size) {
        /*# YOUR CODE HERE */

    } 

    /**   CORE
     * Draw the flag of Laos.
     * The flag has three horizontal stripes with a white circle in the centre;
     * See the assignment for the dimensions.
     */
    public void drawLaosFlag(double left, double top, double width) {
        /*# YOUR CODE HERE */

    }

    /**   COMPLETION
     * Draw the flag of the United Arab Emirates.
     * The flag has a vertical red stripe on the left, and
     * three horizontal stripes (green, white, black) on the right.
     * See the assignment for dimensions and details.
     */
    public void drawUaeFlag(double left, double top, double width) {
        /*# YOUR CODE HERE */

    }

    /**   COMPLETION
     * Draw the flag of Greenland.
     * The top half of the flag is white, and the bottom half is red.
     * There is a circle in the middle (off-set to left)  which is
     * also half white/red but on the opposite sides.
     * See the assignment for dimensions
     */
    public void drawGreenlandFlag(double left, double top, double width) {
        /*# YOUR CODE HERE */

    }

    /**   CHALLENGE
     * Draw the Misubishi Logo.
     */
    public void drawMitsubishiLogo(double left, double top, double size) {
        /*# YOUR CODE HERE */

    }

    /**   CHALLENGE
     * Draw the Koru Flag.
     * It was one of the new flag designs for the 2016 referendum,
     * designed by Sven Baker from Wellington
     * The flag is 1/2 as high as it is wide (ratio 1:2).
     */
    public void drawKoruFlag(double left, double top, double width) {
        /*# YOUR CODE HERE */

    }


}
