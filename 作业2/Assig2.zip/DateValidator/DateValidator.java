// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a XMUT102 assignment.
// You may not distribute it in any other way without permission.

/* Code for XMUT102 - 2018T2
 * Name:
 * Username:
 * ID:
 */

import ecs100.*;
import java.awt.Color;

/**
 * Reads a date from the user as three integers, and then checks that the date is valid
 */

public class DateValidator {

    /**
     * Asks user for three integer and then checks if it is a valid date.
     */
    public void doCore(){
        int day = UI.askInt("Day: ");
        int month = UI.askInt("Month: ");
        int year = UI.askInt("Year: ");
        this.validateDateCore(day, month, year);
    }

    /** CORE
     * Determines whether the date specified by the three integers is a valid date.
     * For the Core, you may assume that
     * - All months have 31 days, numbered 1 to 31
     * - The months run from 1 to 12
     * - Years start from 1 
     */
    public void validateDateCore(int day, int month, int year){
        /*# YOUR CODE HERE */

    }

    /**
     * Asks user for three integer and then checks if it is a valid date.
     */
    public void doCompletion(){
        int day = UI.askInt("Day: ");
        int month = UI.askInt("Month: ");
        int year = UI.askInt("Year (4 digits): ");
        this.validateDateCompletion(day, month, year);
    }

    /** COMPLETION
     * Determines whether the date specified by the three integers is a valid date.
     * For the Completion, you should check that
     * - Months have the correct number of days
     * - Years have 4 digits (between 1000 and 9999)
     * - On leap years February should have 29 days.
     *    A year is a leap year if:
     *       - The year can be evenly divided by 4 but not 100,  OR
     *       - The year can be evenly divided by 400 
     */
    public void validateDateCompletion(int day, int month, int year){
        /*# YOUR CODE HERE */

    }

}

